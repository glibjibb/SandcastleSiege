To start, press VS Self.
To build your sandcastle, choose a player in the upper right and use the build menu to place various parts 
on that player's portion of the map. Player 1 is on the right side, and 2 on the left. You can adjust the
size of various parts with the menu that appears after placing or selecting a piece. When you have a castle
you are happy with, and have placed troops, click Battle to begin. Now, select troops by clicking on them and
click an area to send them towards it. That is all the current functionality enables.